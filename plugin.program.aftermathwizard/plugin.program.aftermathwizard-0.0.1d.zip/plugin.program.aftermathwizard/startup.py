import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import notify
import uservar
import time
import traktit
import datetime
from datetime import date
from addon.common.addon import Addon

ADDON_ID       = uservar.ADDON_ID
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = uservar.ADDONTITLE
USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
VERSION        = ADDON.getAddonInfo('version')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
USERDATA       = os.path.join(HOME,     'userdata')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
FANART         = os.path.join(PLUGIN,   'fanart.jpg')
ICON           = os.path.join(PLUGIN,   'icon.png')
ART            = os.path.join(PLUGIN,   'resources', 'art')
SKIN           = xbmc.getSkinDir()
BUILDNAME      = ADDON.getSetting('buildname')
BUILDVERSION   = ADDON.getSetting('buildversion')
BUILDLATEST    = ADDON.getSetting('latestversion')
BUILDCHECK     = ADDON.getSetting('lastbuildcheck')
KEEPTRAKT      = ADDON.getSetting('keeptrakt')
INSTALLED      = ADDON.getSetting('installed')
EXTRACT        = ADDON.getSetting('extract')
EXTERROR       = ADDON.getSetting('errors')
NOTIFY         = ADDON.getSetting('notify')
NOTEID         = ADDON.getSetting('noteid') 
NOTEID         = 0 if NOTEID == "" else int(NOTEID)
NOTEDISMISS    = ADDON.getSetting('notedismiss')
TODAY          = datetime.date.today()
TOMORROW       = TODAY + datetime.timedelta(days=1)
THREEDAYS      = TODAY + datetime.timedelta(days=3)
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
EXCLUDES       = uservar.EXCLUDES
BUILDURL       = uservar.BUILDURL
BUILDFILE      = uservar.BUILDFILE
NOTIFICATION   = uservar.NOTIFICATION
ENABLE         = uservar.ENABLE

###########################
#### Check Updates   ######
###########################
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
def workingURL(url):
    try: 
	    req = urllib2.Request(url)
	    response = urllib2.urlopen(req)
	    response.close()
    except Exception, e:
	    return e
    return True
	
def updateSettings(name, value=None):
	if name == 'clear':
		ADDON.setSetting('buildname',      '')
		ADDON.setSetting('buildversion',   '')
		ADDON.setSetting('latestversion',  '')
		ADDON.setSetting('lastbuildcheck', '2016-01-01')
		ADDON.setSetting('installed',      'false')
		ADDON.setSetting('extract',        '')
		ADDON.setSetting('errors',         '')
	else: ADDON.setSetting(name, value)
		
def cleanUp():
	ADDON.setSetting('installed', 'false')
	ADDON.setSetting('extract',   '')
	ADDON.setSetting('errors',    '')
		
def checkUpdate():
	BUILDNAME      = ADDON.getSetting('buildname')
	BUILDVERSION   = ADDON.getSetting('buildversion')
	version        = checkBuild(BUILDNAME, 'version')
	ADDON.setSetting('latestversion', version)
	if version > BUILDVERSION:	
		yes_pressed = DIALOG.yesno(ADDONTITLE,"New version of your current build avaliable: %s v%s" % (BUILDNAME, version), "Click Go to Build Page to install update.", yeslabel="Go to Build Page", nolabel="Ignore for 3 days")
		if yes_pressed:
			url = 'plugin://%s/?mode=viewbuild&name=%s' % (ADDON_ID, urllib.quote_plus(BUILDNAME))
			xbmc.executebuiltin('ActivateWindow(10025 ,%s, return)' % url)
			ADDON.setSetting('lastbuildcheck', str(TOMORROW))
		else: 
			DIALOG.ok(ADDONTITLE, 'You can still update %s to %s from the %s.' % (BUILDNAME, version, ADDONTITLE))
			ADDON.setSetting('lastbuildcheck', str(THREEDAYS))
		
def checkBuild(name, ret):
	link  = OPEN_URL(BUILDFILE).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?con="(.+?)".+?anart="(.+?)"' % name).findall(link)
	if len(match) > 0:
		for version, url, gui, icon, fanart in match:
			if   ret == 'version':      return version
			elif ret == 'url':          return url
			elif ret == 'gui':          return gui
			elif ret == 'icon':         return icon
			elif ret == 'fanart':       return fanart
			
if ENABLE == 'Yes' and NOTIFY == 'false':
	url = workingURL(NOTIFICATION)
	if url == True:
		link  = OPEN_URL(NOTIFICATION).replace('\r','').replace('\t','')
		id, msg = link.split('|||')
		if int(id) == NOTEID:
			if NOTEDISMISS == 'false':
				title=ADDONTITLE
				notify.Notification(msg=msg, title=title, BorderWidth=10)
			else: xbmc.log("Notifications id[%s] Dismissed" % int(id))
		elif int(id) > NOTEID:
			xbmc.log("Notifications id: %s" % str(int(id)))
			updateSettings('noteid', str(int(id)))
			updateSettings('notedismiss', 'false')
			title=ADDONTITLE
			openit=notify.Notification(msg=msg, title=title, BorderWidth=10)			
			xbmc.log("Notifications: Complete")
	else: xbmc.log("Notifications URL(%s): %s" % (NOTIFICATION, url))
elif not ENABLE == 'Yes': xbmc.log("Notifications: Not Enabled")
elif NOTIFY == 'true': xbmc.log("Notifications: Turned Off")
			
if INSTALLED == 'true':
	if not EXTRACT == '100':
		yes=DIALOG.yesno(ADDONTITLE, '%s was not installed correctly!' % BUILDNAME, 'Installed: %s / Error Count:%s' % (EXTRACT, EXTERROR), 'Would you like to try again?', nolabel='No Thanks!', yeslabel='Yes Please!')
		if yes: xbmc.executebuiltin("PlayMedia(plugin://%s/?mode=install&name=%s&url=fresh)" % (ADDON_ID, urllib.quote_plus(BUILDNAME)))
	elif SKIN == 'skin.confluence':
		yes=DIALOG.yesno(ADDONTITLE, '%s was not installed correctly!' % BUILDNAME, 'It looks like the skin settings was not applied to the build.', 'Would you like to apply the guiFix?', nolabel='No Thanks!', yeslabel='Yes Please!')
		if yes: xbmc.executebuiltin("PlayMedia(plugin://%s/?mode=install&name=%s&url=gui)" % (ADDON_ID, urllib.quote_plus(BUILDNAME)))
	if KEEPTRAKT == 'true': traktit.traktIt('restore', 'all')
	cleanUp()
	
if BUILDCHECK == '' or not BUILDCHECK > str(TODAY):
	if BUILDNAME == '': 
		yes_pressed = DIALOG.yesno(ADDONTITLE,"Currently no build installed from %s." % ADDONTITLE, "Select 'Build Menu' to install a Community Build", yeslabel="Build Menu", nolabel="Ignore")
		if yes_pressed:	xbmc.executebuiltin('ActivateWindow(10025 , "plugin://%s/?mode=builds", return)' % ADDON_ID)
	else: checkUpdate()
	#if KEEPTRAKT == 'true': traktit.traktIt('restore', 'all')
	updateSettings('lastbuildcheck', str(TOMORROW))