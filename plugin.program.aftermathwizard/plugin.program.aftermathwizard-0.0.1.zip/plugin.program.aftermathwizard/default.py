import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import datetime
import traktit
try:    from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
from datetime import date
from addon.common.addon import Addon
from addon.common.net import Net

#########################################################
### User Edit Variables #################################
#########################################################
ADDON_ID       = 'plugin.program.aftermathwizard'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = 'Aftermath Wizard'
EXCLUDES       = ['script.module.addon.common','plugin.program.aftermathwizard']
BUILDURL       = 'http://cb.srfx.in/builds/'            # Location of the zip files 
BUILDFILE      = 'http://cb.srfx.in/builds.txt'         # Text File with build info in it.
# Message for Contact Page
CONTACT        = 'Thank you for choosing Aftermath Wizard,  Contact us on facebook at http://facebook.com'
COLOR1         = 'dodgerblue'
COLOR2         = 'white'
THEME1         = '[COLOR '+COLOR1+'][Aftermath][/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'    # Primary menu items   / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR1+']%s[/COLOR]'                                          # Build Names          / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'                                          # Alternate items      / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR1+']Current Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]' # Current Build Header / %s is the menu item and is required
#########################################################
#########################################################
#########################################################

USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
VERSION        = ADDON.getAddonInfo('version')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
USERDATA       = os.path.join(HOME,     'userdata')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
ADVANCED       = os.path.join(USERDATA, 'advancedsettings.xml')
SOURCES        = os.path.join(USERDATA, 'sources.xml')
FAVOURITES     = os.path.join(USERDATA, 'favourites.xml')
PROFILES       = os.path.join(USERDATA, 'profiles.xml')
FANART         = os.path.join(PLUGIN,   'fanart.jpg')
ICON           = os.path.join(PLUGIN,   'icon.png')
ART            = os.path.join(PLUGIN,   'resources', 'art')
SKIN           = xbmc.getSkinDir()
BUILDNAME      = ADDON.getSetting('buildname')
BUILDVERSION   = ADDON.getSetting('buildversion')
BUILDLATEST    = ADDON.getSetting('latestversion')
BUILDCHECK     = ADDON.getSetting('lastbuildcheck')
KEEPFAVS       = ADDON.getSetting('keepfavourites')
KEEPSOURCES    = ADDON.getSetting('keepsources')
KEEPPROFILES   = ADDON.getSetting('keepprofiles')
KEEPADVANCED   = ADDON.getSetting('keepadvanced')
KEEPTRAKT      = ADDON.getSetting('keeptrakt')
TRAKT_EXODUS   = ADDON.getSetting('exodus')
TRAKT_SALTS    = ADDON.getSetting('salts')
TRAKT_SALTSHD  = ADDON.getSetting('saltshd')
TRAKT_ROYALWE  = ADDON.getSetting('royalwe')
TRAKT_VELOCITY = ADDON.getSetting('velocity')
TRAKT_VELOKIDS = ADDON.getSetting('velocitykids')
TODAY          = datetime.date.today()
TOMORROW       = TODAY + datetime.timedelta(days=1)
THREEDAYS      = TODAY + datetime.timedelta(days=3)
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
EXODUS         = 'plugin.video.exodus'
VELOCITY       = 'plugin.video.velocity'
VELOCITYKIDS   = 'plugin.video.velocitykids'
SALTS          = 'plugin.video.salts'
SALTSHD        = 'plugin.video.saltshd.lite'
ROYALWE        = 'plugin.video.theroyalwe'
PATHSALTS      = os.path.join(ADDONS, SALTS)
PATHSALTSHD    = os.path.join(ADDONS, SALTSHD)
PATHEXODUS     = os.path.join(ADDONS, EXODUS)
PATHVELOCITY   = os.path.join(ADDONS, VELOCITY)
PATHVELOCITYKI = os.path.join(ADDONS, VELOCITYKIDS)
PATHROYALWE    = os.path.join(ADDONS, ROYALWE)

###########################
###### Menu Items   #######
###########################
#addDir (display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None)
#addFile(display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None)

def index():
	if len(BUILDNAME) > 0:
		version = checkBuild(BUILDNAME, 'version')
		build = '%s (v%s)' % (BUILDNAME, BUILDVERSION)
		if version > BUILDVERSION: build = '%s [COLOR red][B][UPDATE v%s][/B][/COLOR]' % (build, version)
		addDir(build,'viewbuild',BUILDNAME, themeit=THEME4)
	else:                  addDir('None', 'builds', themeit=THEME4)
	addFile('============================================', '', themeit=THEME3)
	addDir ('Builds'       ,'builds',   themeit=THEME1)
	addDir ('Maintenance'  ,'maint',    themeit=THEME1)
	addDir ('Trakt Data'   ,'trakt',    themeit=THEME1)
	addFile('Contact'      ,'contact',  themeit=THEME1)
	addFile('Settings'     ,'settings', themeit=THEME1)
	addFile('Test'         ,'test',     themeit=THEME1)
	setView('movies', 'MAIN')
	
def buildMenu():
	link  = OPEN_URL(BUILDFILE).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall(link)
	for name, version, url, icon, fanart in match:
		menu = createMenu('install', name)
		addDir('%s (v%s)' % (name, version),'viewbuild',name,fanart=fanart,icon=icon, menu=menu, themeit=THEME2)
	setView('movies', 'MAIN')
	
def viewBuild(name):
	version     = checkBuild(name, 'version')
	icon        = checkBuild(name, 'icon')
	fanart      = checkBuild(name, 'fanart')
	build       = '%s (v%s)' % (name, version)
	themefile   = checkBuild(name, 'theme')
	if BUILDNAME == name and version > BUILDVERSION:
		build = '%s [COLOR red][B][CURRENT v%s][/B][/COLOR]' % (build, BUILDVERSION)
	addFile(build, '', fanart=fanart, icon=icon, themeit=THEME2)
	addFile('===============[ Install ]===================', '', fanart=fanart, icon=icon, themeit=THEME3)
	addFile('Fresh Install' , 'install', name, 'fresh'   , fanart=fanart, icon=icon, themeit=THEME1)
	addFile('Normal Install', 'install', name, 'normal'  , fanart=fanart, icon=icon, themeit=THEME1)
	addFile('Apply guiFix'  , 'install', name, 'gui'     , fanart=fanart, icon=icon, themeit=THEME1)
	if not themefile == 'http://':
		print themefile
		addFile('===============[ Themes ]==================', '', fanart=fanart, icon=icon, themeit=THEME3)
		link  = OPEN_URL(themefile).replace('\n','').replace('\r','').replace('\t','')
		match = re.compile('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall(link)
		print len(match)
		for name, url, icon, fanart in match:
			print name
			addFile(name, 'install', name, 'theme', fanart=fanart, icon=icon)
	
def maintMenu():
	addFile('Clear Cache'         ,'clearcache',    themeit=THEME1)
	addFile('Fresh Start'         ,'freshstart',    themeit=THEME1)
	addFile('Clear Packages'      ,'clearpackages', themeit=THEME1)
	addFile('Force Update Addons' ,'forceupdate',   themeit=THEME1)
	setView('movies', 'MAIN')
	
def traktMenu():
	trakt = '[COLOR green]ON[/COLOR]' if KEEPTRAKT == 'true' else '[COLOR red]OFF[/COLOR]'
	addFile('[I]Register FREE Account at http://trakt.tv [/I]', '', themeit=THEME3)
	addFile('Save Trakt Data: %s' % trakt, 'traktsettings', themeit=THEME3)
	addFile('============================================', '', themeit=THEME3)
	addFile('[+]-- Exodus',     '', themeit=THEME3)
	menu = createMenu('traktaddon', 'Exodus'); menu2 = createMenu('trakt', 'Exodus')
	if not os.path.exists(PATHEXODUS):          addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', menu=menu)
	elif not traktit.traktUser('exodus'):       addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt','exodus', menu=menu)
	else:                                       addFile('[COLOR green]Addon Data: %s[/COLOR]' % traktit.traktUser('exodus'),'authtrakt','exodus', menu=menu)
	if TRAKT_EXODUS == "":                      addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt','exodus', menu=menu2)
	else:                                       addFile('[COLOR green]Saved Data: %s[/COLOR]' % TRAKT_EXODUS, '', menu=menu2)
	addFile('[+]-- Salts',     '', themeit=THEME3)
	menu = createMenu('traktaddon', 'Salts'); menu2 = createMenu('trakt', 'Salts')
	if not os.path.exists(PATHSALTS):           addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', menu=menu)
	elif not traktit.traktUser('salts'):        addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt','salts', menu=menu)
	else:                                       addFile('[COLOR green]Addon Data: %s[/COLOR]' % traktit.traktUser('salts'),'authtrakt','salts', menu=menu)
	if TRAKT_SALTS == "":                       addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt','salts', menu=menu2)
	else:                                       addFile('[COLOR green]Saved Data: %s[/COLOR]' % TRAKT_SALTS, '', menu=menu2)
	addFile('[+]-- Salts HD',     '', themeit=THEME3)
	menu = createMenu('traktaddon', 'Salts HD'); menu2 = createMenu('trakt', 'Salts HD')
	if not os.path.exists(PATHSALTSHD):         addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', menu=menu)
	elif not traktit.traktUser('saltshd'):      addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt','saltshd', menu=menu)
	else:                                       addFile('[COLOR green]Addon Data: %s[/COLOR]' % traktit.traktUser('saltshd'),'authtrakt','saltshd', menu=menu)
	if TRAKT_SALTSHD == "":                     addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt','saltshd', menu=menu2)
	else:                                       addFile('[COLOR green]Saved Data: %s[/COLOR]' % TRAKT_SALTSHD, '', menu=menu2)
	addFile('[+]-- Royal We',     '', themeit=THEME3)
	menu = createMenu('traktaddon', 'Royal We'); menu2 = createMenu('trakt', 'Royal We')
	if not os.path.exists(PATHROYALWE):         addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', menu=menu)
	elif not traktit.traktUser('royalwe'):      addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt','royalwe', menu=menu)
	else:                                       addFile('[COLOR green]Addon Data: %s[/COLOR]' % traktit.traktUser('royalwe'),'authtrakt','royalwe', menu=menu)
	if TRAKT_ROYALWE == "":                     addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt','royalwe', menu=menu2)
	else:                                       addFile('[COLOR green]Saved Data: %s[/COLOR]' % TRAKT_ROYALWE, '', menu=menu2)
	addFile('[+]-- Velocity',     '', themeit=THEME3)
	menu = createMenu('traktaddon', 'Velocity'); menu2 = createMenu('trakt', 'Velocity')
	if not os.path.exists(PATHVELOCITY):        addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', menu=menu)
	elif not traktit.traktUser('velocity'):     addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt','velocity', menu=menu)
	else:                                       addFile('[COLOR green]Addon Data: %s[/COLOR]' % traktit.traktUser('velocity'),'authtrakt','velocity', menu=menu)
	if TRAKT_VELOCITY == "":                    addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt','velocity', menu=menu2)
	else:                                       addFile('[COLOR green]Saved Data: %s[/COLOR]' % TRAKT_VELOCITY, '', menu=menu2)
	addFile('[+]-- Velocity Kids',     '', themeit=THEME3)
	menu = createMenu('traktaddon', 'Velocity Kids'); menu2 = createMenu('trakt', 'Velocity Kids')
	if not os.path.exists(PATHVELOCITYKI):      addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', menu=menu)
	elif not traktit.traktUser('velocitykids'): addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt','velocitykids', menu=menu)
	else:                                       addFile('[COLOR green]Addon Data: %s[/COLOR]' % traktit.traktUser('velocitykids'),'authtrakt','velocitykids', menu=menu)
	if TRAKT_VELOKIDS == "":                    addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt','velocitykids', menu=menu2)
	else:                                       addFile('[COLOR green]Saved Data: %s[/COLOR]' % TRAKT_VELOKIDS, '', menu=menu2)
	addFile('============================================', '', themeit=THEME3)
	addFile('Save All Trakt Data',          'savetrakt',    'all',  themeit=THEME3)
	addFile('Recover All Saved Trakt Data', 'restoretrakt', 'all',  themeit=THEME3)
	addFile('Clear All Saved Trakt Data',   'cleartrakt',   'all',  themeit=THEME3)
	addFile('Clear All Addon Data',         'addontrakt',   'all',  themeit=THEME3)
	setView('movies', 'MAIN')

###########################
###### Display Items#######
###########################
	
def TextBoxes(heading,announce):
	class TextBox():
		WINDOW=10147
		CONTROL_LABEL=1
		CONTROL_TEXTBOX=5
		def __init__(self,*args,**kwargs):
			xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
			self.win=xbmcgui.Window(self.WINDOW) # get window
			xbmc.sleep(500) # give window time to initialize
			self.setControls()
		def setControls(self):
			self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
			try: f=open(announce); text=f.read()
			except: text=announce
			self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
			return
	TextBox()
  
def LogNotify(title,message,times=2000,icon=ICON):
	xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % (title , message , times, icon))
	
###########################
###### Build Install ######
###########################
	
def buildWizard(name, type, theme=None):
	if type == 'gui':
		if name == BUILDNAME:
			yes_pressed=DIALOG.yesno(ADDONTITLE, 'Would you like to apply the guifix for:', '%s?' % name, nolabel='No, Cancel',yeslabel='Yes, Apply Fix')
		else: 
			yes_pressed=DIALOG.yesno(ADDONTITLE, "%s community build is not currently installed." % name, "Would you like to apply the guiFix anyways?.", yeslabel="Yes, Apply", nolabel="No, Cancel")
		if yes_pressed:
			buildzip = checkBuild(name,'gui')
			if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
			DP.create(ADDONTITLE,'Downloading %s GuiFix' % name,'', 'Please Wait')
			lib=os.path.join(PACKAGES, '%s_guisettings.zip' % name)
			try: os.remove(lib)
			except: pass
			downloader.download(buildzip, lib, DP)
			time.sleep(2)
			DP.update(0,"", "Installing %s GuiFix" % name)
			extract.all(lib,USERDATA,DP)
			DP.close()
			killxbmc()
		else:
			LogNotify(ADDONTITLE, 'guiFix: [COLOR red]Cancelled![/COLOR]')
	elif type == 'fresh':
		freshStart(name)
	elif type == 'normal':
		yes_pressed = DIALOG.yesno(ADDONTITLE, 'Would you like to install:', '%s v%s?' % (name, checkBuild(name,'version')), nolabel='No, Cancel',yeslabel='Yes, Install')
		if yes_pressed:
			buildzip = checkBuild(name,'url')
			if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
			DP.create(ADDONTITLE,'Downloading %s ' % name,'', 'Please Wait')
			lib=os.path.join(PACKAGES, '%s.zip' % name)
			try: os.remove(lib)
			except: pass
			downloader.download(buildzip, lib, DP)
			time.sleep(2)
			DP.update(0,"", "Installing %s " % name)
			ext = extract.all(lib,HOME,DP)
			percent, errors, error = ext.split('/')
			updateSettings('buildname', name)
			updateSettings('buildversion', checkBuild( name,'version'))
			updateSettings('latestversion', checkBuild( name,'version'))
			updateSettings('lastbuildcheck', str(TODAY))
			updateSettings('installed', 'true')
			updateSettings('extract', str(percent))
			updateSettings('errors', str(errors))
			print 'INSTALLED %s: [ERRORS:%s] %s' % (percent, errors, error)
			if int(errors) >= 1:
				yes=DIALOG.yesno(ADDONTITLE, 'INSTALLED %s: [ERRORS:%s]' % (percent, errors), 'Would you like to view the errors?', nolabel='No, Cancel',yeslabel='Yes, View')
				if yes:
					TextBoxes(ADDONTITLE, error)
			DP.close()
			DIALOG.ok(ADDONTITLE, "To save changes you now need to force close Kodi, Press OK to force close Kodi")
			killxbmc()
		else:
			LogNotify(ADDONTITLE, 'Build Install: [COLOR red]Cancelled![/COLOR]')
	elif type == 'theme':
		yes_pressed = DIALOG.yesno(ADDONTITLE, 'Would you like to install the theme: %s' % theme , 'for %s v%s?' % (name, checkBuild(name,'version')), nolabel='No, Cancel',yeslabel='Yes, Install')
		if yes_pressed:
			themezip = checkTheme(name, theme)
			if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
			DP.create(ADDONTITLE,'Downloading %s ' % name,'', 'Please Wait')
			lib=os.path.join(PACKAGES, '%s.zip' % name)
			try: os.remove(lib)
			except: pass
			downloader.download(themezip, lib, DP)
			time.sleep(2)
			DP.update(0,"", "Installing %s " % name)
			ext = extract.all(lib,HOME,DP)
			percent, errors, error = ext.split('/')
			updateSettings('buildtheme', name)
			print 'INSTALLED %s: [ERRORS:%s] %s' % (percent, errors, error)
			DP.close()
			DIALOG.ok(ADDONTITLE, "To save changes you now need to force close Kodi, Press OK to force close Kodi")
			killxbmc()
		else:
			LogNotify(ADDONTITLE, 'Theme Install: [COLOR red]Cancelled![/COLOR]')
	
###########################
###### Misc Functions######
###########################
	
def forceUpdate():
	xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('UpdateLocalAddons()')
	LogNotify(ADDONTITLE, 'Forcing Check Updates')
	
def updateSettings(name, value=None):
	if name == 'clear':
		ADDON.setSetting('buildname',      '')
		ADDON.setSetting('buildversion',   '')
		ADDON.setSetting('buildtheme',     '')
		ADDON.setSetting('latestversion',  '')
		ADDON.setSetting('lastbuildcheck', '2016-01-01')
		ADDON.setSetting('installed',      'false')
		ADDON.setSetting('extract',        '')
		ADDON.setSetting('errors',         '')
	else: ADDON.setSetting(name, value)

def checkBuild(name, ret):
	link  = OPEN_URL(BUILDFILE).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)"' % name).findall(link)
	if len(match) > 0:
		for version, url, gui, theme, icon, fanart in match:
			if   ret == 'version':      return version
			elif ret == 'url':          return url
			elif ret == 'gui':          return gui
			elif ret == 'theme':        return theme
			elif ret == 'icon':         return icon
			elif ret == 'fanart':       return fanart
	else: return False
	
def checkTheme(name, ret):
	themeurl = checkBuild(name, 'theme')
	link  = OPEN_URL(themeurl).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('name="%s".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"' % name).findall(link)
	if len(match) > 0:
		for url, icon, fanart in match:
			if ret == 'url':            return url
			elif ret == 'icon':         return icon
			elif ret == 'fanart':       return fanart
	else: return False
	
def percentage(part, whole):
  return 100 * float(part)/float(whole)
  
def OPEN_URL(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', USER_AGENT)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
	
def themeit(display, theme):
	if theme == '1':
		print 'theme1'
		
def createMenu(type, name):
	if type == 'trakt':
		menu_items=[]
		name2 = urllib.quote_plus(name.lower().replace(' ', ''))
		menu_items.append((THEME2 % name,             ' '))
		menu_items.append((THEME2 % 'Save Trakt Data',         'RunPlugin(plugin://%s/?mode=savetrakt&name=%s)' %    (ADDON_ID, name2)))
		menu_items.append((THEME2 % 'Restore Trakt Data',      'RunPlugin(plugin://%s/?mode=restoretrakt&name=%s)' % (ADDON_ID, name2)))
		menu_items.append((THEME2 % 'Clear Trakt Data',        'RunPlugin(plugin://%s/?mode=cleartrakt&name=%s)' %   (ADDON_ID, name2)))
	if type == 'traktaddon':
		menu_items=[]
		name2 = urllib.quote_plus(name.lower().replace(' ', ''))
		menu_items.append((THEME2 % name,             ' '))
		menu_items.append((THEME2 % 'Register Trakt',          'RunPlugin(plugin://%s/?mode=authtrakt&name=%s)' %    (ADDON_ID, name2)))
		menu_items.append((THEME2 % 'Save Trakt Data',         'RunPlugin(plugin://%s/?mode=savetrakt&name=%s)' %    (ADDON_ID, name2)))
		menu_items.append((THEME2 % 'Restore Trakt Data',      'RunPlugin(plugin://%s/?mode=restoretrakt&name=%s)' % (ADDON_ID, name2)))
		menu_items.append((THEME2 % 'Clear Addon Trakt Data',  'RunPlugin(plugin://%s/?mode=addontrakt&name=%s)' %   (ADDON_ID, name2)))
	if type == 'install':
		menu_items=[]
		name2 = urllib.quote_plus(name)
		menu_items.append((THEME2 % name,             ' '))	
		menu_items.append((THEME2 % 'Fresh Install',          'RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'  % (ADDON_ID, name2)))
		menu_items.append((THEME2 % 'Normal Install',         'RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)' % (ADDON_ID, name2)))
		menu_items.append((THEME2 % 'Apply guiFix',           'RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'    % (ADDON_ID, name2)))
	menu_items.append((THEME2 % 'Aftermath Settings', 'RunPlugin(plugin://%s/?mode=settings)' % ADDON_ID))
	return menu_items


##########################
###DETERMINE PLATFORM#####
##########################

def platform():
	if   xbmc.getCondVisibility('system.platform.android'): return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):   return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'): return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):	    return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):    return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):	    return 'ios'
	
###########################
###### Fresh Install ######
###########################

def freshStart(install=None):
	if SKIN != 'skin.confluence': DIALOG.ok(ADDONTITLE, "Please set the default skin back to 'Confluence'", "Before doing a fresh install!", "Press the back button to return to this menu after changing skin."); xbmc.executebuiltin("ActivateWindow(appearancesettings,return)")
	else:
		if install: yes_pressed=DIALOG.yesno(ADDONTITLE,"Do you wish to restore your","Kodi configuration to default settings", "Before installing %s?" % install, nolabel='No, Cancel',yeslabel='Yes, Continue')
		else: yes_pressed=DIALOG.yesno(ADDONTITLE,"Do you wish to restore your","Kodi configuration to default settings?", nolabel='No, Cancel',yeslabel='Yes, Continue')
		if yes_pressed:
			xbmcPath=os.path.abspath(HOME)
			DP.create(ADDONTITLE,"Clearing all files and folders:",'', '')
			total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0;
			try:
				for root, dirs, files in os.walk(xbmcPath,topdown=True):
					dirs[:] = [d for d in dirs if d not in EXCLUDES]
					for name in files:
						del_file += 1
						fold = root.split('\\')
						x = len(fold)-1
						if name == 'sources.xml' and fold[x] == 'userdata' and KEEPSOURCES == 'true': xbmc.log("Keep Sources: %s\\%s" % (root, name))
						elif name == 'favourites.xml' and fold[x] == 'userdata' and KEEPFAVS == 'true': xbmc.log("Keep Favourites: %s\\%s" % (root, name))
						elif name == 'profiles.xml' and fold[x] == 'userdata' and KEEPPROFILES == 'true': xbmc.log("Keep Profiles: %s\\%s" % (root, name))
						elif name == 'advancedsettings.xml' and fold[x] == 'userdata' and KEEPADVANCED == 'true':  xbmc.log("Keep Advanced Settings: %s\\%s" % (root, name))
						elif name == 'kodi.log': xbmc.log("Keep kodi.log")
						else:
							DP.update(int(percentage(del_file, total_files)), '', 'File: [COLOR yellow]%s[/COLOR]' % name, '')
							try: os.remove(os.path.join(root,name))
							except: xbmc.log("Error removing %s\\%s" % (root, name))
				for root, dirs, files in os.walk(xbmcPath,topdown=True):
					dirs[:] = [d for d in dirs if d not in EXCLUDES]							
					for name in dirs:
						DP.update(100, '', 'Cleaning Up Empty Folder: [COLOR yellow]%s[/COLOR]' % name, '')
						if name not in ["Database","userdata","temp","addons","addon_data"]:
							shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
				DP.close()
				updateSettings('clear')
			except: 
				DIALOG.ok(ADDONTITLE,"Problem found","Your settings has not been changed")
				import traceback
				xbmc.log(traceback.format_exc())
				xbmc.log("freshstart.main_list NOT removed")
			DP.close()
			if install: 
				DIALOG.ok(ADDONTITLE, "Your current setup for kodi has been cleared!", "Now we will install: %s v%s" % (install, checkBuild(install,'version')))
				buildWizard(install, 'normal')
			else:
				DIALOG.ok(ADDONTITLE, "The process is complete, you're now back to a fresh Kodi configuration with Aftermath Wizard","Please reboot your system or restart Kodi in order for the changes to be applied.")
				killxbmc()
		else: LogNotify(ADDONTITLE,'Fresh Install: [COLOR red]Cancelled![/COLOR]'); xbmc.executebuiltin('Container.Refresh')
	
############################
###DELETE PACKAGES##########
####THANKS GUYS @ XUNITY####
######MODIFIED BY AFTERMATH#

def clearPackages():
	if os.path.exists(PACKAGES):
		try:	
			for root, dirs, files in os.walk(PACKAGES):
				file_count = 0
				file_count += len(files)
				# Count files and give option to delete
				if file_count > 0:
					if DIALOG.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
						for f in files:	os.unlink(os.path.join(root, f))
						for d in dirs: shutil.rmtree(os.path.join(root, d))
						LogNotify(ADDONTITLE,'Clear Packages: [COLOR green]Success[/COLOR]!')
				else: LogNotify(ADDONTITLE,'Clear Packages: [COLOR red]None Found![/COLOR]')
		except: LogNotify(ADDONTITLE,'Clear Packages: [COLOR red]Error[/COLOR]!')
	else: LogNotify(ADDONTITLE,'Clear Packages: [COLOR red]None Found![/COLOR]')

#############################
###DELETE CACHE##############
####THANKS GUYS @ XUNITY#####

def clearCache():
	print '############################################################	   DELETING STANDARD CACHE			 ###############################################################'
	thumb = xbmc.translatePath('special://home/userdata/Thumbnails/')
	xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
	if os.path.exists(xbmc_cache_path)==True:	
		for root, dirs, files in os.walk(xbmc_cache_path):
			file_count = 0
			file_count += len(files)
			# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files:
						try: os.unlink(os.path.join(root, f))
						except: pass
					for d in dirs:
						try: shutil.rmtree(os.path.join(root, d))
						except: pass
					LogNotify(ADDONTITLE,'Clear Cache: [COLOR green]Success![/COLOR]')
			else: pass

	if xbmc.getCondVisibility('system.platform.ATV2'):
		atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
		for root, dirs, files in os.walk(atv2_cache_a):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				if DIALOG.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
					LogNotify(ADDONTITLE,'Clear Cache: [COLOR green]Success![/COLOR]')
			else: pass
		atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
		for root, dirs, files in os.walk(atv2_cache_b):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				if DIALOG.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
					LogNotify(ADDONTITLE,'Clear Cache: [COLOR green]Success![/COLOR]')
			else: pass
			
	# Set path to Cydia Archives cache files
	# Set path to What th Furk cache files
	wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
	if os.path.exists(wtf_cache_path)==True:	
		for root, dirs, files in os.walk(wtf_cache_path):
			file_count = 0
			file_count += len(files)
			# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
					LogNotify(ADDONTITLE,'Clear Cache: [COLOR green]Success![/COLOR]')
			else: pass		
			
	# Set path to 4oD cache files
	channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
	if os.path.exists(channel4_cache_path)==True:	
		for root, dirs, files in os.walk(channel4_cache_path):
			file_count = 0
			file_count += len(files)		
			# Count files and give option to delete
			if file_count > 0:	
				if DIALOG.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
					LogNotify(ADDONTITLE,'Clear Cache: [COLOR green]Success![/COLOR]')
			else: pass
				
	# Set path to BBC iPlayer cache files
	iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
	if os.path.exists(iplayer_cache_path)==True:	
		for root, dirs, files in os.walk(iplayer_cache_path):
			file_count = 0
			file_count += len(files)
			# Count files and give option to delete
			if file_count > 0:	
				if DIALOG.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
					LogNotify(ADDONTITLE,'Clear Cache: [COLOR green]Success![/COLOR]')
			else: pass			
				
	# Set path to Simple Downloader cache files
	downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
	if os.path.exists(downloader_cache_path)==True:	
		for root, dirs, files in os.walk(downloader_cache_path):
			file_count = 0
			file_count += len(files)
			# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
					LogNotify(ADDONTITLE,'Clear Cache: [COLOR green]Success![/COLOR]')
			else: pass
				
	# Set path to ITV cache files
	itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
	if os.path.exists(itv_cache_path)==True:	
		for root, dirs, files in os.walk(itv_cache_path):
			file_count = 0
			file_count += len(files)		
			# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
					LogNotify(ADDONTITLE,'Clear Cache: [COLOR green]Success![/COLOR]')
			else: pass

	# Set path to temp cache files
	temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
	if os.path.exists(temp_cache_path)==True:	
		for root, dirs, files in os.walk(temp_cache_path):
			file_count = 0
			file_count += len(files)
			# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete TEMP dir Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
					LogNotify(ADDONTITLE,'Clear Cache: [COLOR green]Success![/COLOR]')
			else: pass
	
	if DIALOG.yesno(ADDONTITLE, "Would you like to delete the Textures13.db and Thumbnails folder?", "They will repopulate on startup", nolabel='No, Cancel',yeslabel='Yes, Remove'):
		textures()
		removeFolder(thumb)
		killxbmc()

def textures():
	textfile = xbmc.translatePath('special://home/userdata/Database/Textures13.db')
	try :
		textdb = database.connect(textfile)
		textexe = textdb.cursor()
		textexe.execute("DROP TABLE IF EXISTS path")
		textexe.execute("VACUUM")
		textdb.commit()
		textexe.execute("DROP TABLE IF EXISTS sizes")
		textexe.execute("VACUUM")
		textdb.commit()
		textexe.execute("DROP TABLE IF EXISTS texture")
		textexe.execute("VACUUM")
		textdb.commit()
		textexe.execute("""CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))""")
		textdb.commit()
		textexe.execute("""CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)""")
		textdb.commit()
		textexe.execute("""CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))""")
		textdb.commit()
		print 'DB Complete'
	except Exception, e:
		print str(e)

def removeFolder(path):
	print "Deleting Folder: %s" % path
	try: shutil.rmtree(path,ignore_errors=True, onerror=None)
	except: pass
	
			
#############################
####KILL XBMC ###############
#####THANKS GUYS @ TI########

def killxbmc():
	choice = DIALOG.yesno('Force Close Kodi', 'You are about to close Kodi', 'Would you like to continue?', nolabel='No, Cancel',yeslabel='Yes, Close')
	if choice == 0:   return
	elif choice == 1: pass
	myplatform = platform()
	print "Platform: " + str(myplatform)
	if myplatform == 'osx': # OSX
		print "############   try osx force close  #################"
		try: os.system('killall -9 XBMC')
		except: pass
		try: os.system('killall -9 Kodi')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
	elif myplatform == 'linux': #Linux
		print "############   try linux force close  #################"
		try: os.system('killall XBMC')
		except: pass
		try: os.system('killall Kodi')
		except: pass
		try: os.system('killall -9 xbmc.bin')
		except: pass
		try: os.system('killall -9 kodi.bin')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
	elif myplatform == 'android': # Android  
		print "############   try android force close  #################"
		try: os.system('adb shell am force-stop org.xbmc.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc.xbmc')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc')
		except: pass		
		try: os.system('adb shell kill org.xbmc.kodi')
		except: pass
		try: os.system('adb shell kill org.kodi')
		except: pass
		try: os.system('adb shell kill org.xbmc.xbmc')
		except: pass
		try: os.system('adb shell kill org.xbmc')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc,kodi());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.kodi());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc.xbmc());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc());')
		except: pass
		DIALOG.ok("[COLOR=yellow][B]TO COMPLETE AFTERMATH INSTALL[/COLOR][/B]", "Press the HOME button on your remote and [COLOR=red][B]FORCE STOP[/COLOR][/B] KODI via the Manage Installed Applications menu in settings on your Amazon home page then re-launch KODI")
	elif myplatform == 'windows': # Windows
		print "############   try windows force close  #################"
		try:
			os.system('@ECHO off')
			os.system('tskill XBMC.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('tskill Kodi.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im Kodi.exe /f')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im XBMC.exe /f')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
	else: #ATV
		print "############   try atv force close  #################"
		try: os.system('killall AppleTV')
		except: pass
		print "############   try raspbmc force close  #################" #OSMC / Raspbmc
		try: os.system('sudo initctl stop kodi')
		except: pass
		try: os.system('sudo initctl stop xbmc')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")	
	
###########################
## Making the Directory####
###########################

def addDir(display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None):
		u='%s?mode=%s' % (sys.argv[0], urllib.quote_plus(mode))
		if not name == None: u += "&name="+urllib.quote_plus(name)
		if not url == None: u += "&url="+urllib.quote_plus(url)
		ok=True
		if themeit: display = themeit % display
		liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
		liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": ADDONTITLE} )
		liz.setProperty( "Fanart_Image", fanart )
		if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
	 	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
		
def addFile(display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None):
		u='%s?mode=%s' % (sys.argv[0], urllib.quote_plus(mode))
		if not name == None: u += "&name="+urllib.quote_plus(name)
		if not url == None: u += "&url="+urllib.quote_plus(url)
		ok=True
		if themeit: display = themeit % display
		liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
		liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": ADDONTITLE} )
		liz.setProperty( "Fanart_Image", fanart )
		if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param


params=get_params()
url=None
name=None
mode=None

try:	 mode=urllib.unquote_plus(params["mode"])
except:  pass
try:	 name=urllib.unquote_plus(params["name"])
except:  pass
try:	 url=urllib.unquote_plus(params["url"])
except:  pass
		
print '%s: %s' % (ADDONTITLE, VERSION)
print "Mode: %s" % mode
print "Name: %s" % name
print "Url: %s" % url

def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )

if   mode==None            : index()

elif mode=='builds'        : buildMenu()
elif mode=='viewbuild'     : viewBuild(name)
elif mode=='install'       : buildWizard(name, url)
elif mode=='theme'         : buildWizard(name, mode, url)

elif mode=='maint'         : maintMenu()
elif mode=='clearcache'    : clearCache()
elif mode=='freshstart'    : freshStart()
elif mode=='clearpackages' : clearPackages()
elif mode=='forceupdate'   : forceUpdate()

elif mode=='trakt'         : traktMenu()
elif mode=='savetrakt'     : traktit.traktIt('update',      name)
elif mode=='restoretrakt'  : traktit.traktIt('restore',     name)
elif mode=='cleartrakt'    : traktit.traktIt('clear',       name)
elif mode=='addontrakt'    : traktit.traktIt('clearaddon',  name)
elif mode=='authtrakt'     : traktIt.activateTrakt(name)
elif mode=='traktsettings'  : updateSettings('keeptrakt', 'false' if KEEPTRAKT == 'true' else 'true'); xbmc.executebuiltin('Container.Refresh()')

elif mode=='contact'       : TextBoxes(ADDONTITLE, CONTACT)
elif mode=='settings'      : ADDON.openSettings(); xbmc.executebuiltin('Container.Refresh()')

elif mode=='test'          : StartAndroidActivity('com.android.providers.downloads.ui')

xbmcplugin.endOfDirectory(int(sys.argv[1]))